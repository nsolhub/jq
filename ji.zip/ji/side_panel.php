<!-- Sidebar Holder -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>Panel</h3>
                    <strong>CV</strong>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">
                            <i class="glyphicon glyphicon-home"></i>
                            Personal Details
                        </a>
                        <ul class="collapse list-unstyled" id="homeSubmenu">

                            <div class="" style="margin: 10px;">
                                 <label> Full Name </label>
                            <div class="form-group">
                                <input type="text" name="fullname" id="idInput_fullname" placeholder="Enter Full Name" class="form-control">
                                <button onclick="btnPut_fullname()" class="text-center btn btn-primary"> Put </button>
                            </div>

                            <hr style="background: #fff;">
                            </div>

                             <div class="" style="margin: 10px;">
                                 <label> Father Name </label>
                            <div class="form-group">
                                <input type="text" name="fullname" id="idInput_fathername" placeholder="Enter Father Name" class="form-control">
                                <button onclick="btnPut_fathername()" class="text-center btn btn-primary"> Put </button>
                            </div>
                            <hr style="background: #fff;">
                            </div>
                             <div class="" style="margin: 10px;">
                                 <label> Occupation </label>
                            <div class="form-group">
                                <input type="text" name="fullname" id="idInput_occupation" placeholder="Enter Occupation" class="form-control">
                                <button onclick="btnPut_occupation()" class="text-center btn btn-primary"> Put </button>
                            </div>
                            <hr style="background: #fff;">
                            </div>
                            <script type="text/javascript">
                                function okay(){
                                    var get = getElementById('idp_fullname').id = "okay";
                                }

                            </script>

                        
                            
                        </ul>
                    </li>
                    <li>
                        <a href="#about" data-toggle="collapse" aria-expanded="false">
                            <i class="glyphicon glyphicon-briefcase"></i>
                            About
                        </a>
                        <ul class="collapse list-unstyled" id="about">
                            <div class="" style="margin: 10px;">
                            <div class="form-group">
                                <input type="text" name="fullname" id="id_fullname" placeholder="Enter Full Name" class="form-control">
                                <button onclick="btnPut_fullname()" class="text-center btn btn-primary"> Put </button>
                            </div>

                            <script type="text/javascript">
                                function okay(){
                                    var get = getElementById('idp_fullname').id = "okay";
                                }

                            </script>

                        </div>
                            
                        </ul>
                        <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false">
                            <i class="glyphicon glyphicon-duplicate"></i>
                            Pages
                        </a>
                        <ul class="collapse list-unstyled" id="pageSubmenu">
                            <li><a href="#">Page 1</a></li>
                            <li><a href="#">Page 2</a></li>
                            <li><a href="#">Page 3</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">
                            <i class="glyphicon glyphicon-link"></i>
                            Portfolio
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="glyphicon glyphicon-paperclip"></i>
                            FAQ
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="glyphicon glyphicon-send"></i>
                            Contact
                        </a>
                    </li>
                </ul>

                <ul class="list-unstyled CTAs">
                    <li><a href="https://bootstrapious.com/tutorial/files/sidebar.zip" class="download">Download source</a></li>
                    <li><a href="https://bootstrapious.com/p/bootstrap-sidebar" class="article">Back to article</a></li>
                </ul>
            </nav>