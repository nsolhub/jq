<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class ComplaintModel extends CI_Model
{
	public function insert_complaint($data){
		$this->db->insert('tbl_complaint', $data);
		
	}
}
