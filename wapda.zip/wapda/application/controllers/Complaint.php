<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Complaint extends CI_Controller {


	public function __construct()
	{
		$all = array("customer", "member", "admin");
		parent::__construct();
		$this->load->database();
		$this->load->library(['ion_auth', 'form_validation']);
		$this->load->helper(['url', 'language']);

		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

		
	}

	
	public function index()
	{
		global $all;
		if ($this->ion_auth->in_group($all)){
			redirect('auth', 'refresh');
		}
		$this->load->view('register_complaint');
	}

	public function add_complaint(){
		
		if ($this->ion_auth->in_group($all)){
			redirect('auth', 'refresh');}


	}

	public function store(){
		global $all;
		if ($this->ion_auth->in_group($all)){
			redirect('auth', 'refresh');}

		$c_title = $this->input->post('c_title');
		$c_description = $this->input->post('c_description');
		$c_email = $this->input->post('c_email');
		$c_address = $this->input->post('c_address');
		$c_phone = $this->input->post('c_phone');
		$c_division = $this->input->post('c_division');

		$data = array(
					
					'c_title' => $c_title,
					'c_description' => $c_description,
					'c_email' => $c_email,
					'c_address' => $c_address,
					'c_phone' => $c_phone,
					'fk_division_id' => $c_division);

		
		$this->load->model('complaintModel');
		$result = $this->complaintModel->insert_complaint($data);

		if($result){
			set_flash("msg", "succesffully inserted");
			redirect()->$this->index();
		}

	}
		
	

}
