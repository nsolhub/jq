<?php include('inc/head.php') ?>


<body>
	<div class="container-scroller">
	  	<?php include('inc/nav.php') ?>
	  	<div class="container-fluid page-body-wrapper">
	  		<?php include('inc/sidebar.php') ?>
	  		<div class="main-panel">
		        <div class="content-wrapper">
		        	<!-- content of the page goes here  -->
					<div class="row ">
						<h2 class="">Register a New Complaint</h2>
					</div>

					<div class=" col-lg-12 grid-margin stretch-card">
						
		              <div class="card">
		                <div class="card-body">
		                  <h4 class="card-title">Fill the form</h4>
		                  
		                 	<div class="">
					<form class="forms-sample" action="<?= base_url();?>index.php/Complaint/store" method="POST">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Title of the Complaint</label>
                          <input type="text" class="form-control input-lg" name="c_title" placeholder="Enter email">
                        </div>

                        <div class="form-group">
                          <label for="exampleInputEmail1">Description of the Complaint</label>
                          <textarea type="text" class="form-control input-lg" name="c_description" placeholder="Enter Description" rows="5"></textarea>
                        </div>

                       <div class="form-group">
                          <label for="exampleInputEmail1">Email of the Complainer</label>
                          <input type="title" class="form-control input-lg" name="c_email" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Address of the Complainer</label>
                          <input type="title" class="form-control input-lg" name="c_address" placeholder="Enter email">
                        </div>

                        <div class="form-group">
                          <label for="exampleInputEmail1">Phone of the Complainer</label>
                          <input type="title" class="form-control input-lg" name="c_phone" placeholder="Enter email">
                        </div>

                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Division</label>
                          <div class="col-sm-9">
                            <select class="form-control" name="c_division">
                              <option value="1">ISB 1</option>
                              <option value="2">ISB 2</option>
                            </select>
                          </div>
                        </div>

                        <button type="submit" class="btn btn-success mr-2" id="btn_submit">Submit</button>
                        <button class="btn btn-light">Cancel</button>
                      </form>
		                 	</div>
					
				</div>
					</div>
				</div>
		<footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with
              <i class="mdi mdi-heart text-danger"></i>
            </span>
          </div>
        </footer>
	</div>
          <!--  content of the page went off here  -->

    <?php include('inc/footer.php'); ?>