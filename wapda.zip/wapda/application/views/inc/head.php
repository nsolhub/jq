<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Wapda</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?= base_url();?>asset/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?= base_url();?>asset/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
  <link rel="stylesheet" href="<?= base_url();?>asset/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?= base_url();?>asset/css/style.css">

  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
</head>
