<!-- plugins:js -->
  <script src="<?= base_url();?>asset/js/vendor.bundle.base.js"></script>
  <script src="<?= base_url();?>asset/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?= base_url();?>asset/js/off-canvas.js"></script>
  <script src="<?= base_url();?>asset/js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?= base_url();?>asset/js/dashboard.js"></script>